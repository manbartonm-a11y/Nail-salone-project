<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_staff();

$db = get_db();
$employeeId = (int)$_SESSION['staff_employee_id'];
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceId = (int)$_POST['service_id'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $fullName = clean($_POST['full_name'] ?? '');
    $phone = clean($_POST['phone'] ?? '');
    $concern = clean($_POST['concern'] ?? '');

    if (!$serviceId || !$date || !$time || !$fullName || !$phone) {
        $error = 'Please fill in all fields.';
    } else {
        $svcStmt = $db->prepare("SELECT * FROM services WHERE id = ? AND active = 1");
        $svcStmt->execute([$serviceId]);
        $service = $svcStmt->fetch();

        if (!$service) {
            $error = "That treatment isn't available.";
        } else {
            $clientId = find_or_create_client($fullName, $phone, 'staff', null);
            $ins = $db->prepare(
                "INSERT INTO bookings (service_id, employee_id, client_id, full_name, phone, channel, appointment_date, appointment_time, concern, status, source)
                 VALUES (?, ?, ?, ?, ?, 'staff', ?, ?, ?, 'pending', 'staff')"
            );
            $ins->execute([$serviceId, $employeeId, $clientId, $fullName, $phone, $date, $time, $concern ?: null]);
            $bookingId = $db->lastInsertId();

            $notifMsg = "{$_SESSION['staff_name']} requested a booking: {$fullName} — {$service['name']} on {$date} at {$time}.";
            $db->prepare("INSERT INTO notifications (type, message, related_booking_id, is_read) VALUES ('new_booking', ?, ?, 0)")
                ->execute([$notifMsg, $bookingId]);

            $success = "Booking request sent — waiting for Natalie's confirmation.";
        }
    }
}

$services = $db->query("SELECT * FROM services WHERE active = 1 ORDER BY category, name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>New Booking | Staff</title>
<link rel="stylesheet" href="../admin/admin.css">
</head>
<body>

<div class="admin-topbar">
  <strong>Nataly Laser House — Staff</strong>
  <div class="nav">
    <a href="dashboard.php">Bookings</a>
    <a href="calendar.php">Calendar</a>
    <a href="clients.php">Clients</a>
    <a href="book.php" class="active">New Booking</a>
    <a href="logout.php">Log out</a>
  </div>
</div>

<div class="admin-main">
  <div class="card">
    <h3>Request a new booking</h3>
    <p style="color:#999;font-size:.85rem;">This will be added to the calendar as <strong>pending</strong> until Natalie confirms it.</p>
    <?php if ($error): ?><p class="admin-error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
    <?php if ($success): ?><p style="color:#3f9d6e;"><?= htmlspecialchars($success) ?></p><?php endif; ?>
    <form method="post">
      <label>Client name</label>
      <input type="text" name="full_name" required style="width:100%;margin-bottom:10px;">
      <label>Client phone</label>
      <input type="text" name="phone" required style="width:100%;margin-bottom:10px;">
      <label>Service</label>
      <select name="service_id" required style="width:100%;margin-bottom:10px;">
        <?php foreach ($services as $s): ?>
          <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['category']) ?>)</option>
        <?php endforeach; ?>
      </select>
      <label>Date</label>
      <input type="date" name="date" required style="width:100%;margin-bottom:10px;">
      <label>Time</label>
      <input type="time" name="time" required style="width:100%;margin-bottom:10px;">
      <label>Notes (optional)</label>
      <textarea name="concern" rows="2" style="width:100%;margin-bottom:10px;"></textarea>
      <button type="submit" class="btn-sm btn-confirm">Submit request</button>
    </form>
  </div>
</div>

</body>
</html>